export class ModelFilter {
  selectedNation: string;
  maleFilter: boolean;
  femaleFilter: boolean;
  maxResultNum: string;
}
